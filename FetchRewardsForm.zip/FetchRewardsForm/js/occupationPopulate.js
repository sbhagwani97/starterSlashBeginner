var populateOccupations = function(){
    var occupations = jQuery.getJSON("https://frontend-take-home.fetchrewards.com/form", function(data){
        var occupations = data["occupations"]
        //console.log(occupations[0])
        if($("#occupation").children().length == 0){
            for ( var i = 0, l = occupations.length; i < l; i++ ) {
                //console.log(occupations[i])
                $("#occupation").append("<option value='"+i+"'>"+occupations[i]+"</option>")
            }
        }
    })
}