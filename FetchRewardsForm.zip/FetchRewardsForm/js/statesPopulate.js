var populateStates = function(){
    var occupations = jQuery.getJSON("https://frontend-take-home.fetchrewards.com/form", function(data){
        var states = data["states"]
        //console.log(states[0])
        if($("#states").children().length == 0){
            for ( var i = 0, l = states.length; i < l; i++ ) {
                console.log(states[i])
                $("#states").append("<option value='"+i+"'>"+states[i]["name"]+"</option>")
            }
    }
    })
}